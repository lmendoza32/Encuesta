package com.example.encuesta

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var chk1 = findViewById<CheckBox>(R.id.cboxPython) as CheckBox
        var chk2 = findViewById<CheckBox>(R.id.cboxCpp) as CheckBox
        var chk3 = findViewById<CheckBox>(R.id.cboxJava) as CheckBox
        var chk4 = findViewById<CheckBox>(R.id.cboxCSharp) as CheckBox

        var boton = findViewById<Button>(R.id.button_Encuesta) as Button
        var texto = findViewById<TextView>(R.id.textViewRespuestas) as TextView

        boton.setOnClickListener {
            var res:String = ""
            if(chk1.isChecked()==true)
            {
                res = res + " Python"
            }
            if(chk2.isChecked()==true)
            {
                res = res + " C++"
            }
            if(chk3.isChecked()==true)
            {
                res = res + " Java"
            }
            if(chk4.isChecked()==true)
            {
                res = res + " C#"
            }
            texto.setText("La selección fue: "+ res)
        }
    }
}